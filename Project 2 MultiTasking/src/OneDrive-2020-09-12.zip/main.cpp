#include <arduino.h>
#include "digital_out.h"
#include "digital_in.h"
#include "analog_in.h"
#include "analog_out.h"

Digital_out digiout(5);
Digital_in  digiin(4);
Analog_in analogIn(0);
Analog_out analogOut(0.5);
int val = 0;

void setup() {

digiout.init();
digiin.init();
analogIn.init();
analogOut.init();
sei(); 
Serial.begin(9600); 
}

void loop() {

  val = analogIn.getval();
  Serial.println(digiin.is_hi());
  
  Serial.println(val);
  
  analogOut.dutyset(val/(float)255);

}

// Interrupt routines

ISR(TIMER1_COMPB_vect)
{

PORTB &= ~(1 << 5);

}

ISR(TIMER1_COMPA_vect)
{

PORTB |= (1 << 5);

}